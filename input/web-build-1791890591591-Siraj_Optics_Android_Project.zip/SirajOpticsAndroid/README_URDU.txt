Siraj Optics Offline Android App Project

یہ Android Studio project ہے، تیار شدہ APK نہیں۔ APK بنانے کے لیے Android build service استعمال کرنا ہوگا۔

اہم خصوصیات: offline catalogue، lens photo، colour name، price، customer view۔

احتیاط: APK بنانے کے لیے کسی بھی website پر GitHub token/password کسی شخص کے ساتھ share نہ کریں۔ صرف قابلِ اعتماد service استعمال کریں اور token میں کم سے کم permissions دیں۔
