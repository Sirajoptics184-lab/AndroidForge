package com.sirajoptics.catalogue;
import android.app.Activity; import android.os.Bundle; import android.webkit.*; import android.content.Intent; import android.net.Uri;
public class MainActivity extends Activity {
 private WebView webView; private ValueCallback<Uri[]> uploadMessage; private static final int FILE_CHOOSER_RESULT=1001;
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(0xFF152238);webView=new WebView(this);WebSettings s=webView.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);s.setAllowContentAccess(true);s.setDatabaseEnabled(true);
 webView.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams params){if(uploadMessage!=null)uploadMessage.onReceiveValue(null);uploadMessage=cb;try{startActivityForResult(params.createIntent(),FILE_CHOOSER_RESULT);}catch(Exception e){uploadMessage=null;return false;}return true;}});
 setContentView(webView);webView.loadUrl("file:///android_asset/index.html");}
 @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==FILE_CHOOSER_RESULT&&uploadMessage!=null){uploadMessage.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode,data));uploadMessage=null;}}
 @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
