Siraj Optics — Eye Side No Book

Ye Android Studio project hai, compiled APK nahi.
Features:
- Aap ka shop logo aur background branding
- Prescription photo customer ke naam se save
- Optional eye number aur date
- Naam se search, record open/delete
- Offline storage (IndexedDB)
- JSON backup export/import

APK banane ke liye computer par Android Studio aur Android SDK/Gradle build chahiye:
1. ZIP extract karein.
2. Android Studio mein folder open karein.
3. Gradle Sync hone dein.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) select karein.

Note: Records isi device par save hote hain. App/browser data clear karne ya uninstall karne se pehle backup export karein.
